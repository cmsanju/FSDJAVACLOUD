package com.progressivecoder.demo.subscriberapplication;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class SubscriberApplicationTests {

	@Test
	public void contextLoads() {
	}

}
